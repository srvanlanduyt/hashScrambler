//
//  ScrambleButtonView.swift
//  HashScrambler
//
//  Created by Steven Van Landuyt on 12/17/19.
//  Copyright © 2019 Standard App Co. All rights reserved.
//

import SwiftUI

struct ScrambleButtonView: View {
    var body: some View {
        Text("scramble")
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 42, maxHeight: 42)
            .font(Font.system(size: 30))
            .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.orange]), startPoint: .top, endPoint: .bottom))
            .cornerRadius(10)
            .foregroundColor(.white)
            .padding(.bottom, 5)
            .padding(.horizontal, 5)
    }
}

struct ScrambleButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ScrambleButtonView()
    }
}
