//
//  ContentView.swift
//  HashScrambler
//
//  Created by Steven Van Landuyt on 12/14/19.
//  Copyright © 2019 Standard App Co. All rights reserved.
//

import SwiftUI


struct ContentView: View {

    @State private var newGroupName = ""
    @State private var newGroupList = ""
    
    @Environment(\.managedObjectContext)
    
    var viewContext
 
    var body: some View {
        
        NavigationView {
           List {
                Section(header: Text("Add a New Group")) {
                    TextField("New Group Name", text: $newGroupName)
                    HStack {
                        TextField("Enter New Items", text: $newGroupList)
                        if newGroupName.count > 0 && newGroupList.count > 0 {
                            Button(action: {
                                withAnimation { Group.create(name: self.newGroupName, list: self.newGroupList, in: self.viewContext) }
                                self.newGroupName = ""
                                self.newGroupList = ""
                            }) {
                                Image(systemName: "plus.circle.fill")
                                    .foregroundColor(.green)
                                    .imageScale(.large)
                            }
                        }
                    }
                }
                Section(header: Text("Saved Groups")) {
                    RowView()
                }
           }
                .navigationBarTitle(Text("Hash Scrambler"))
                .navigationBarItems(trailing: EditButton())
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        return ContentView().environment(\.managedObjectContext, context)
    }
}
