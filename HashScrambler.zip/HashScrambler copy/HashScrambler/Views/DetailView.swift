//
//  DetailView.swift
//  HashScrambler
//
//  Created by Steven Van Landuyt on 12/15/19.
//  Copyright © 2019 Standard App Co. All rights reserved.
//

import SwiftUI
import Foundation

private let dateFormatter: DateFormatter = {
    let dateFormatter = DateFormatter()
    dateFormatter.dateStyle = .medium
    dateFormatter.timeStyle = .medium
    return dateFormatter
}()


struct DetailView: View {
    
    @ObservedObject var group: Group
    @State private var newGroupItem = ""
    @State private var newScrambleNumber = ""
    @State private var showScramble = false
    @State private var outStringHeader = ""
    @State private var outString = ""
    var tempArray = [String]()
    
    var body: some View {
        
        
        
        //Header
        VStack {
            
            //date created
           HStack {
                if group.createdAt != nil {
                   Text("\(group.createdAt!, formatter: dateFormatter)")
                       .font(Font.system(size: 10))
                       .padding(.horizontal)
                   Spacer()
                }
           }
            
            HStack {
                //number of items display
                if group.array != nil {
                    Text("Number of Items: \(getNumOfItems(array: group.array!))")
                        .font(.subheadline)
                        .padding(.horizontal)
                    Spacer()
                }
                //favorite start logic
                if group.isFavorite {
                    Button(action: {
                        withAnimation {
                            self.group.isFavorite = false
                        }
                    }) {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                            .imageScale(.large)
                            .padding(.horizontal)
                    }
                } else {
                    Button(action: {
                        withAnimation {
                            self.group.isFavorite = true
                        }
                    }) {
                        Image(systemName: "star")
                            .imageScale(.large)
                            .padding(.horizontal)
                    }
                }
            }
            
            HStack {
                Text("Number of Times Used: \(group.numTimesUsed)")
                    .font(.subheadline)
                    .padding(.horizontal)
                Spacer()
            }
            
            VStack {
                HStack {
                    HStack {
                        if group.array != nil {
                            TextField("\(setText(size: getNumOfItems(array: group.array!)))", text: $newScrambleNumber).keyboardType(.numberPad)
                                
                             if (Int(newScrambleNumber) ?? 0 > 0 && Int(newScrambleNumber) ?? 0 <= (getNumOfItems(array: group.array!))) && (Int(newScrambleNumber) ?? 0 > 1) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                    .imageScale(.large)
                             } else {
                                Image(systemName: "xmark.octagon.fill")
                                    .foregroundColor(.red)
                                    .imageScale(.large)
                            }
                        }
                    }
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .padding(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray, lineWidth: 1)
                        )
                    .padding(.horizontal, 5)
                    .padding(.top, 5)
                }
                
                Button(action: {
                    if (self.newScrambleNumber.isEmpty || self.newScrambleNumber == "0" || self.stringToInt(string: self.newScrambleNumber) == 0) {
                        self.outStringHeader = "Error... Try again"
                        self.outString = "You must choose how many items to return."
                        self.showScramble = true
                        self.newScrambleNumber = ""
                    } else if (!(Int(self.newScrambleNumber) ?? 0 > 0 && Int(self.newScrambleNumber) ?? 0 <= (self.getNumOfItems(array: self.group.array!))) && (Int(self.newScrambleNumber) ?? 0 > 1)) || (self.stringToInt(string: self.newScrambleNumber) == 1) {
                        self.outString = ("You must choose between 2 and \(self.getNumOfItems(array: self.group.array!)) items based on the size of your group.")
                        self.outStringHeader = "Error... Try again"
                        self.showScramble = true
                        self.newScrambleNumber = ""
                    } else {
                        self.outString = ("\(HashTagger(input: (Scrambler(requestedHashes: Int(self.newScrambleNumber)!, groupArray: self.group.array!))))")
                        self.outStringHeader = "Copied HashScramble"
                        UIPasteboard.general.string = self.outString
                        self.showScramble = true
                        self.newScrambleNumber = ""
                        self.group.numTimesUsed += 1
                    }
                 }) {
                    ScrambleButtonView()
                }
                
                
            }
            .padding(5)
        //EndHeader
        

            List {
        //AddToList
                Section(header: Text("Add to Group")) {
                    HStack {
                        TextField("Add New Items", text: $newGroupItem)
                        if newGroupItem.count != 0 {
                            //TODO - add more safeguards for other chars
                            Button(action: {
                                 withAnimation {
                                     self.addToArray(newItem: self.newGroupItem)
                                }
                                 self.newGroupItem = ""
                             }) {
                                 Image(systemName: "plus.circle.fill")
                                     .foregroundColor(.green)
                                     .imageScale(.large)
                            }
                        }
                    }
                }
                Section(header: Text("Saved Items")) {
        //Body
                    if (group.array != nil && group.array!.count != 0) {
                        ForEach(group.array!, id: \.self) { item in
                            Text(item.self)
                        }.onDelete(perform: delete)
                    } else {
                        Text("There are no items associated with this group, please add them above.")
                            .foregroundColor(.red)
                    }
                }
            }
            .navigationBarTitle(Text("\(setGroupName())"))
            .navigationBarItems(trailing: EditButton())

            .alert(isPresented: $showScramble) {
                Alert(title: Text("\(outStringHeader)"), message: Text("\(outString)"))
            }

        }
        //EndBody  \(HashTagger(input: (Scrambler(requestedHashes: Int(newScrambleNumber)!, groupArray: group.array!))))
        
    }
    
    
    func setText(size: Int) -> String {
        if size == 0 {
            return "Add Items Below to Scramble..."
        } else if size == 1 {
            return "Can't Scramble Just 1 Item..."
        } else {
            return "Number of Items to Scramble (2 - \(getNumOfItems(array: group.array!)))"
        }
    }
    
    func setGroupName() -> String {
        if group.name != nil {
            return group.name!
        } else {
            return " "
        }
    }
    
    
    func getNumOfItems(array: [String]) -> Int {
        return array.count
    }
    
    
    func addToArray(newItem: String) {
       group.array! += cleanArray(array: makeArray(list: newItem))
        group.createdAt = Date()
    }
    
    
    func delete(at offsets: IndexSet) {
        group.array!.remove(atOffsets: offsets)
        group.createdAt = Date()
    }
    

    func intToString(array: Int) -> String {
        let myString = String(array)
        return myString
    }
    
    
    func stringToInt(string: String) -> Int {
        guard let myInt = Int(string) else { return 0 }
        return myInt
    }
}


