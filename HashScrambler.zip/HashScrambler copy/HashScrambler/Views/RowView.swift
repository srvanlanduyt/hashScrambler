//
//  RowView.swift
//  HashScrambler
//
//  Created by Steven Van Landuyt on 12/15/19.
//  Copyright © 2019 Standard App Co. All rights reserved.
//

import SwiftUI

private let dateFormatter: DateFormatter = {
    let dateFormatter = DateFormatter()
    dateFormatter.dateStyle = .medium
    dateFormatter.timeStyle = .medium
    return dateFormatter
}()


struct RowView: View {
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Group.isFavorite, ascending: false)],
        animation: .default)
    var groups: FetchedResults<Group>

    @Environment(\.managedObjectContext)
    var viewContext

    var body: some View {
        ForEach(groups, id: \.self) { group in
            NavigationLink(
                destination: DetailView(group: group)
            ) {
                HStack {
                    VStack(alignment: .leading) {
                        Text("\(group.name!)")
                        Text("\(group.createdAt!, formatter: dateFormatter)")
                            .font(.system(size: 10))
                    }
                    Spacer()
                    if group.isFavorite {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                            .imageScale(.large)
                    }
                }
            }
        }.onDelete { indices in
            self.groups.delete(at: indices, from: self.viewContext)
        }
    }
}


struct RowView_Previews: PreviewProvider {
    static var previews: some View {
        RowView()
    }
}
