//
//  Group.swift
//  HashScrambler
//
//  Created by Steven Van Landuyt on 12/14/19.
//  Copyright © 2019 Standard App Co. All rights reserved.
//

import SwiftUI
import CoreData

extension Group: Identifiable {

    static func create(name: String, list: String, in managedObjectContext: NSManagedObjectContext){
        let newGroup = self.init(context: managedObjectContext)
        newGroup.name = name
        newGroup.list = list
        newGroup.createdAt = Date()
        newGroup.array = cleanArray(array: makeArray(list: list))
        
        do {
            try  managedObjectContext.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }   
}


func makeArray(list: String) -> [String] {
    return list.components(separatedBy: " ")
}


func cleanArray(array: [String]) -> [String] {
    var outputArray = array
    let pattern = "[^A-Za-z0-9]+"
    
    for i in outputArray.indices.reversed() {
        if outputArray[i] == "" || outputArray[i] == " " {
            outputArray.remove(at: i)
    }
    
    for j in 0...outputArray.count - 1 {
        outputArray[j] = outputArray[j].replacingOccurrences(of: pattern, with: "", options: [.regularExpression])
    }
        
    for k in 0...outputArray.count - 1 {
        if outputArray[k] == "" || outputArray[k] == " " {
            outputArray.remove(at: k)
        }
    }
}
    
    return outputArray
}


extension Collection where Element == Group, Index == Int {
    func delete(at indices: IndexSet, from managedObjectContext: NSManagedObjectContext) {
        indices.forEach { managedObjectContext.delete(self[$0]) }       
 
        do {
            try managedObjectContext.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }
}
