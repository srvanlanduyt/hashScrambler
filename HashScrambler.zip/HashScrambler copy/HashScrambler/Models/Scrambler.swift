//
//  Scrambler.swift
//  HashScrambler
//
//  Created by Steven Van Landuyt on 12/20/19.
//  Copyright © 2019 Standard App Co. All rights reserved.
//

import Foundation
import SwiftUI
import CoreData

public var intList = [Int]()
public var outOrder = [Int]()
public var outputString = String()
public var requestedHashes = Int()
public var groupArray = [String]()


func Scrambler(requestedHashes: Int, groupArray: [String]) -> String {
    intList = []
    outOrder = []
    outputString = ""
    
    
    for i in 0...requestedHashes - 1 {
        intList.append(i)
    }
    
    while intList.count != 0 {
        for _ in 0...intList.count - 1 {
            let randomInt = Int.random(in: 0...intList.count - 1)
            outOrder.append(intList[randomInt])
            intList.remove(at: randomInt)
        }
    }
    
    for k in 0...outOrder.count - 1 {
        outputString.append(contentsOf: groupArray[outOrder[k]])
        outputString.append(" ")
    }
    
    return outputString
}
