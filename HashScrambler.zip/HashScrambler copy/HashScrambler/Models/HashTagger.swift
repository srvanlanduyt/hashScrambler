//
//  HashTagger.swift
//  HashScrambler
//
//  Created by Steven Van Landuyt on 12/21/19.
//  Copyright © 2019 Standard App Co. All rights reserved.
//

import Foundation
import SwiftUI
import CoreData

public var hashedOutput = ""
public var hashedStringArray = [String]()

func HashTagger (input: String) -> String {
    hashedOutput = ""
    hashedStringArray = input.components(separatedBy: " ")
    
    for i in 0...hashedStringArray.count - 2 {
        if !(hashedStringArray[i].starts(with: "#")) {
            hashedOutput.append(contentsOf: "#")
            hashedOutput.append(contentsOf: "\(hashedStringArray[i]) ")
            print("IF: \(hashedStringArray.count) / \(hashedStringArray[i]) / \(hashedOutput)")

        } else {
            hashedOutput.append(contentsOf: "\(hashedStringArray[i]) ")
            print("ELSE: \(hashedStringArray.count) / \(hashedStringArray[i]) / \(hashedOutput)")

        }
    }
    return hashedOutput
}
